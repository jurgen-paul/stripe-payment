// File generated from our OpenAPI spec
package com.stripe;

final class ApiVersion {
  public static final String CURRENT = "2025-01-27.acacia";
}
