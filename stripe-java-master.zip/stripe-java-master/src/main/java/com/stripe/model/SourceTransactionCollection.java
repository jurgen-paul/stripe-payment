// File generated from our OpenAPI spec
package com.stripe.model;

public class SourceTransactionCollection extends StripeCollection<SourceTransaction> {}
