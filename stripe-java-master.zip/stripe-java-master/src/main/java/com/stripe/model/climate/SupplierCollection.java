// File generated from our OpenAPI spec
package com.stripe.model.climate;

import com.stripe.model.StripeCollection;

public class SupplierCollection extends StripeCollection<Supplier> {}
