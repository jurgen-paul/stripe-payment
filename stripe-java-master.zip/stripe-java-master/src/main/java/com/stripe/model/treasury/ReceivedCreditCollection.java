// File generated from our OpenAPI spec
package com.stripe.model.treasury;

import com.stripe.model.StripeCollection;

public class ReceivedCreditCollection extends StripeCollection<ReceivedCredit> {}
