// File generated from our OpenAPI spec
package com.stripe.model.reporting;

import com.stripe.model.StripeCollection;

public class ReportTypeCollection extends StripeCollection<ReportType> {}
