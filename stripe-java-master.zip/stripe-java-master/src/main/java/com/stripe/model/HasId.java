package com.stripe.model;

public interface HasId {
  String getId();
}
