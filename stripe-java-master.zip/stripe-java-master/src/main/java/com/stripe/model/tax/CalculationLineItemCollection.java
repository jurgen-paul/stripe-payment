// File generated from our OpenAPI spec
package com.stripe.model.tax;

import com.stripe.model.StripeCollection;

public class CalculationLineItemCollection extends StripeCollection<CalculationLineItem> {}
