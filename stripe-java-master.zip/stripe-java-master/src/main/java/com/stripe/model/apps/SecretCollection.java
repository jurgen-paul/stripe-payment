// File generated from our OpenAPI spec
package com.stripe.model.apps;

import com.stripe.model.StripeCollection;

public class SecretCollection extends StripeCollection<Secret> {}
