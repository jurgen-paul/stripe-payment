// File generated from our OpenAPI spec
package com.stripe.model.billing;

import com.stripe.model.StripeCollection;

public class CreditGrantCollection extends StripeCollection<CreditGrant> {}
