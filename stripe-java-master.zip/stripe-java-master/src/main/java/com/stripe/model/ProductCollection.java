// File generated from our OpenAPI spec
package com.stripe.model;

public class ProductCollection extends StripeCollection<Product> {}
