// File generated from our OpenAPI spec
package com.stripe.model;

public class SubscriptionSearchResult extends StripeSearchResult<Subscription> {}
