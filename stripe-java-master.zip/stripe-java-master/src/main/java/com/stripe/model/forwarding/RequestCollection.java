// File generated from our OpenAPI spec
package com.stripe.model.forwarding;

import com.stripe.model.StripeCollection;

public class RequestCollection extends StripeCollection<Request> {}
