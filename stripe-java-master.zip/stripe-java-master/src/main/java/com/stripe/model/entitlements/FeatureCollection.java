// File generated from our OpenAPI spec
package com.stripe.model.entitlements;

import com.stripe.model.StripeCollection;

public class FeatureCollection extends StripeCollection<Feature> {}
