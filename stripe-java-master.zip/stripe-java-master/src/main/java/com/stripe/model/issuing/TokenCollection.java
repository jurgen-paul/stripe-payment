// File generated from our OpenAPI spec
package com.stripe.model.issuing;

import com.stripe.model.StripeCollection;

public class TokenCollection extends StripeCollection<Token> {}
