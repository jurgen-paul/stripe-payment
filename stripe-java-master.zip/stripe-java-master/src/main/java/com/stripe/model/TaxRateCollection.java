// File generated from our OpenAPI spec
package com.stripe.model;

public class TaxRateCollection extends StripeCollection<TaxRate> {}
