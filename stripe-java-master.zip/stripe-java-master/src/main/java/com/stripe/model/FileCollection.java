// File generated from our OpenAPI spec
package com.stripe.model;

public class FileCollection extends StripeCollection<File> {}
