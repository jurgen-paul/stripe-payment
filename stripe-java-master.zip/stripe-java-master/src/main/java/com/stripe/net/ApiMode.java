package com.stripe.net;

public enum ApiMode {
  V1,
  V2
}
