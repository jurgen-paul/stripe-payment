<template>
  <div class="sr-root">
    <div class="sr-main">
      <header class="sr-header">
        <div class="sr-header__logo" />
      </header>

      <div class="sr-payment-summary completed-view">
        <h1>Your payment was canceled</h1>
        <router-link to="/">
          Restart demo
        </router-link>
      </div>
    </div>

    <div class="sr-content">
      <div class="pasha-image-stack">
        <img
          src="https://picsum.photos/280/320?random=1"
          width="140"
          height="160"
        >
        <img
          src="https://picsum.photos/280/320?random=2"
          width="140"
          height="160"
        >
        <img
          src="https://picsum.photos/280/320?random=3"
          width="140"
          height="160"
        >
        <img
          src="https://picsum.photos/280/320?random=4"
          width="140"
          height="160"
        >
      </div>
    </div>
  </div>
</template>
